const index = function(req,res){
res.render('about', {title:'Welcome to the music store'});
};
module.exports ={
    index
};
